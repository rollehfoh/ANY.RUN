class Config:
    VERSION: str = 'MS_Sentinel:1.0.0'

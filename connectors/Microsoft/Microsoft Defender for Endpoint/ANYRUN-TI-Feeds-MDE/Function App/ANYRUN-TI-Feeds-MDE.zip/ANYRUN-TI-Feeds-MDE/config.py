class Config:
    """ Configuration class """
    DEFENDER_API_URL: str = "https://api.securitycenter.microsoft.com"
    VERSION: str = 'MS_Defender:1.0.0'

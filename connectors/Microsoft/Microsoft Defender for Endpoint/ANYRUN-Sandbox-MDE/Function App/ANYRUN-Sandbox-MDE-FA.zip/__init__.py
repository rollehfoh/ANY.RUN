{
            "Indicators": [
                {
                    "indicatorValue": '151.101.65.44',
                    "title": "IoC from ANY.RUN Sandbox",
                    "description": f"https://app.any.run/tasks/123",
                    "action": "Allow",
                    "severity": "Medium",
                    "indicatorType": "IpAddress"
                }
            ]
        }